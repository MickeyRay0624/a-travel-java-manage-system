

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address`  (
                            `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                            `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                            `userid` bigint NOT NULL COMMENT '用户id',
                            `address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '地址',
                            `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '收货人',
                            `phone` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '电话',
                            `isdefault` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '是否默认地址[是/否]',
                            PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614757746499 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '地址' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of address
-- ----------------------------
INSERT INTO `address` VALUES (1, '2024-05-13 15:14:31', 1, '宇宙银河系金星1号', '金某', '13823888881', '是');
INSERT INTO `address` VALUES (2, '2024-05-13 15:14:31', 2, '宇宙银河系木星1号', '木某', '13823888882', '是');
INSERT INTO `address` VALUES (3, '2024-05-13 15:14:31', 3, '宇宙银河系水星1号', '水某', '13823888883', '是');
INSERT INTO `address` VALUES (4, '2024-05-13 15:14:31', 4, '宇宙银河系火星1号', '火某', '13823888884', '是');
INSERT INTO `address` VALUES (5, '2024-05-13 15:14:31', 5, '宇宙银河系土星1号', '土某', '13823888885', '是');
INSERT INTO `address` VALUES (6, '2024-05-13 15:14:31', 6, '宇宙银河系月球1号', '月某', '13823888886', '是');
INSERT INTO `address` VALUES (1614757033717, '2024-05-13 15:37:13', 1614756982123, '广东省揭阳市榕城区中山街道北环城路16号中兴园', '陈一', '12312312312', '是');
INSERT INTO `address` VALUES (1614757746498, '2024-05-13 15:49:05', 1614757696160, '广东省揭阳市榕城区中山街道Show艺数字油画中兴园', '陈一', '12312312312', '是');


-- ----------------------------
-- Table structure for cart
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart`  (
                         `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                         `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                         `tablename` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT 'zuixinxianlu' COMMENT '商品表名',
                         `userid` bigint NOT NULL COMMENT '用户id',
                         `goodid` bigint NOT NULL COMMENT '商品id',
                         `goodname` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '商品名称',
                         `picture` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '图片',
                         `buynumber` int NOT NULL COMMENT '购买数量',
                         `price` float NULL DEFAULT NULL COMMENT '单价',
                         `discountprice` float NULL DEFAULT NULL COMMENT '会员价',
                         PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614758018422 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '购物车表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cart
-- ----------------------------
INSERT INTO `cart` VALUES (1614757109452, '2024-05-13 15:38:28', 'lvyouxianlu', 1614756982123, 1614756810110, '云南大理丽江6天5晚', 'http://localhost:8080/travels/upload/1614756714294.jpg', 1, 2000, 0);
INSERT INTO `cart` VALUES (1614758018421, '2024-05-13 15:53:37', 'zuixinxianlu', 1614757696160, 1614757619035, '桂林4天3晚', 'http://localhost:8080/travels/upload/1614757585872.png', 1, 1200, 0);
INSERT INTO `cart` VALUES (1708866928139, '2024-02-25 21:15:27', 'lvyouxianlu', 1708860588725, 32, '西藏珠峰大本营5日游 ', 'http://localhost:8080/travels/upload/1708861571858.jpeg', 1, 2999, 0);
INSERT INTO `cart` VALUES (1708867182846, '2024-02-25 21:19:41', 'zuixinxianlu', 1708860588725, 41, '杭州西湖景区', 'http://localhost:8080/travels/upload/zuixinxianlu_fengmiantu1.jpg', 2, 99.9, 0);
INSERT INTO `cart` VALUES (1708867208682, '2024-02-25 21:20:08', 'lvyouxianlu', 1708860588725, 33, '张家界凤凰古城5日游（森林公园+天门山+玻璃桥', 'http://localhost:8080/travels/upload/1708862205541.jpeg', 2, 999, 0);

-- ----------------------------
-- Table structure for chat
-- ----------------------------
DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat`  (
                         `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                         `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                         `userid` bigint NOT NULL COMMENT '用户id',
                         `adminid` bigint NULL DEFAULT NULL COMMENT '管理员id',
                         `ask` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '提问',
                         `reply` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '回复',
                         `isreply` int NULL DEFAULT NULL COMMENT '是否回复',
                         PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614757928393 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '客服聊天表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of chat
-- ----------------------------
INSERT INTO `chat` VALUES (51, '2024-05-13 15:14:31', 1, 1, '提问1', '回复1', 1);
INSERT INTO `chat` VALUES (52, '2024-05-13 15:14:31', 2, 2, '提问2', '回复2', 2);
INSERT INTO `chat` VALUES (53, '2024-05-13 15:14:31', 3, 3, '提问3', '回复3', 3);
INSERT INTO `chat` VALUES (54, '2024-05-13 15:14:31', 4, 4, '提问4', '回复4', 4);
INSERT INTO `chat` VALUES (55, '2024-05-13 15:14:31', 5, 5, '提问5', '回复5', 5);
INSERT INTO `chat` VALUES (56, '2024-05-13 15:14:31', 6, 6, '提问6', '回复6', 6);
INSERT INTO `chat` VALUES (1614757183618, '2024-05-13 15:39:43', 1614756982123, NULL, '请问有国外旅游线路吗', NULL, 0);
INSERT INTO `chat` VALUES (1614757346257, '2024-05-13 15:42:26', 1614756982123, 1, NULL, '1', NULL);
INSERT INTO `chat` VALUES (1614757887672, '2024-05-13 15:51:26', 1614757696160, NULL, '请问有国外的旅游线路吗', NULL, 0);
INSERT INTO `chat` VALUES (1614757928392, '2024-05-13 15:52:07', 1614757696160, 1, NULL, '暂时没有', NULL);
INSERT INTO `chat` VALUES (1708867415367, '2024-02-25 21:23:34', 1708860588725, NULL, '你好', NULL, 1);

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config`  (
                           `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                           `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '配置参数名称',
                           `value` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '配置参数值',
                           PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '配置文件' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config
-- ----------------------------
INSERT INTO `config` VALUES (1, 'picture1', 'http://localhost:8080/travels/upload/1708865055717.jpg');
INSERT INTO `config` VALUES (2, 'picture2', 'http://localhost:8080/travels/upload/1708865116520.jpg');
INSERT INTO `config` VALUES (3, 'picture3', 'http://localhost:8080/travels/upload/1708865078067.jpeg');

-- ----------------------------
-- Table structure for discusslvyouxianlu
-- ----------------------------
DROP TABLE IF EXISTS `discusslvyouxianlu`;
CREATE TABLE `discusslvyouxianlu`  (
                                       `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                                       `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                                       `refid` bigint NOT NULL COMMENT '关联表id',
                                       `userid` bigint NOT NULL COMMENT '用户id',
                                       `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '评论内容',
                                       `reply` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '回复内容',
                                       PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614757117445 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '旅游线路评论表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of discusslvyouxianlu
-- ----------------------------
INSERT INTO `discusslvyouxianlu` VALUES (111, '2024-05-13 15:14:31', 1, 1, '评论内容1', '回复内容1');
INSERT INTO `discusslvyouxianlu` VALUES (112, '2024-05-13 15:14:31', 2, 2, '评论内容2', '回复内容2');
INSERT INTO `discusslvyouxianlu` VALUES (113, '2024-05-13 15:14:31', 3, 3, '评论内容3', '回复内容3');
INSERT INTO `discusslvyouxianlu` VALUES (114, '2024-05-13 15:14:31', 4, 4, '评论内容4', '回复内容4');
INSERT INTO `discusslvyouxianlu` VALUES (115, '2024-05-13 15:14:31', 5, 5, '评论内容5', '回复内容5');
INSERT INTO `discusslvyouxianlu` VALUES (116, '2024-05-13 15:14:31', 6, 6, '评论内容6', '回复内容6');
INSERT INTO `discusslvyouxianlu` VALUES (1614757117444, '2024-05-13 15:38:37', 1614756810110, 1614756982123, '不错的路线', NULL);
INSERT INTO `discusslvyouxianlu` VALUES (1708861703217, '2024-02-25 19:48:22', 32, 1708860588725, '不错嘛', NULL);

-- ----------------------------
-- Table structure for discusszuixinxianlu
-- ----------------------------
DROP TABLE IF EXISTS `discusszuixinxianlu`;
CREATE TABLE `discusszuixinxianlu`  (
                                        `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                                        `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                                        `refid` bigint NOT NULL COMMENT '关联表id',
                                        `userid` bigint NOT NULL COMMENT '用户id',
                                        `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '评论内容',
                                        `reply` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '回复内容',
                                        PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614757866075 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '最新线路评论表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of discusszuixinxianlu
-- ----------------------------
INSERT INTO `discusszuixinxianlu` VALUES (121, '2024-05-13 15:14:31', 1, 1, '评论内容1', '回复内容1');
INSERT INTO `discusszuixinxianlu` VALUES (122, '2024-05-13 15:14:31', 2, 2, '评论内容2', '回复内容2');
INSERT INTO `discusszuixinxianlu` VALUES (123, '2024-05-13 15:14:31', 3, 3, '评论内容3', '回复内容3');
INSERT INTO `discusszuixinxianlu` VALUES (124, '2024-05-13 15:14:31', 4, 4, '评论内容4', '回复内容4');
INSERT INTO `discusszuixinxianlu` VALUES (125, '2024-05-13 15:14:31', 5, 5, '评论内容5', '回复内容5');
INSERT INTO `discusszuixinxianlu` VALUES (126, '2024-05-13 15:14:31', 6, 6, '评论内容6', '回复内容6');
INSERT INTO `discusszuixinxianlu` VALUES (1614757866074, '2024-05-13 15:51:05', 1614757619035, 1614757696160, '不错的旅游线路', NULL);

-- ----------------------------
-- Table structure for lvyouxianlu
-- ----------------------------
DROP TABLE IF EXISTS `lvyouxianlu`;
CREATE TABLE `lvyouxianlu`  (
                                `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                                `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                                `xianlumingcheng` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '线路名称',
                                `xianlufenlei` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '线路分类',
                                `fengmiantu` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '封面图',
                                `jingdianmingcheng` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '景点名称',
                                `chufadi` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '出发地',
                                `mudedi` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '目的地',
                                `jiaotongfangshi` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '交通方式',
                                `chuxingshijian` datetime NULL DEFAULT NULL COMMENT '出行时间',
                                `feiyongbaohan` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '费用包含',
                                `xingchengluxian` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '行程路线',
                                `clicktime` datetime NULL DEFAULT NULL COMMENT '最近点击时间',
                                `clicknum` int NULL DEFAULT 0 COMMENT '点击次数',
                                `price` float NOT NULL COMMENT '价格',
                                PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614757564119 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '旅游线路' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lvyouxianlu
-- ----------------------------
INSERT INTO `lvyouxianlu` VALUES (31, '2024-05-13 15:14:31', '上海迪士尼含门票+早享卡提前入园+快速游玩8大经典项目', '度假旅游', 'http://localhost:8080/travels/upload/lvyouxianlu_fengmiantu1.jpg', '上海迪士尼度假区', '杭州', '上海', '飞机', '2024-02-25 11:42:53', '景点门票	\n行程中所列景点首道大门票\n\n餐食	\n行程中所列餐食，本行程不含餐，全程餐费自理\n\n司导服务	\n当地中文导游', '<h3>上海迪士尼</h3><p>&nbsp;早餐:自理&nbsp;&nbsp;午餐:自理&nbsp;&nbsp;晚餐:自理&nbsp;</p><p>07:10</p><h4>集合</h4><p>集合事宜：</p><p>1、上午7:10准时在迪士尼大门集合。</p><p>2、迟到请自行排队游玩，不再提供导游服务，自行承担损失，敬请谅解！</p><p>3、依据园区开园时间。集合时间可能提前或推后，具体以导游通知为准，感谢您的配合。</p><p>07:30</p><h4>上海迪士尼乐园</h4><p>经典热门8大项目：</p><p>1. 飞跃地平线 2. 七个小矮人矿山车 3. 雷鸣山漂流 4. 创极速光轮 5. 加勒比海盗 6. 胡迪牛仔嘉年华 7. 巴斯光年星际营救</p><p>8. 小飞侠天空奇遇记</p><p>13:30</p><h4>上海迪士尼度假区</h4><p>自由活动散团，下午自行继续游玩和欣赏迪士尼其它项目。</p><p><br></p><p>表演节目：</p><p>1. 冰雪奇缘欢唱盛会。2. 加勒比海盗之风暴来临。</p><p><br></p><p>温馨提示：因疫情或雷电下雨等客观原因，园区可能会取消演出。</p><p>15:30</p><h4>上海迪士尼度假区</h4><p>欣赏：迪士尼花车巡游-米奇童话专列。</p><p><br></p><p><br></p><p>温馨提示：因疫情或雷电下雨等客观原因，园区可能会取消巡游。</p><p>20:00</p><h4>上海迪士尼度假区</h4><p>欣赏精彩的迪士尼烟花灯光秀。</p><p>点亮奇梦：夜光幻影秀，点亮夜空，美轮美奂。</p><p><br></p><p>温馨提示：因疫情或雷电下雨等客观原因，园区可能会取消演出。</p><p>21:00</p><h4>解散</h4><p><br></p><p>自行选择交通工具返程，结束愉快旅程！</p><p><img src=\"https://sales.mafengwo.net/mfs/s17/M00/65/FC/CoUBXmAUylSAISCjABhKde3T3CI50.jpeg?imageView2%2F2%2Fw%2F1000%2Fq%2F90\"></p>', '2024-02-25 12:47:34', 7, 1799);
INSERT INTO `lvyouxianlu` VALUES (32, '2024-05-13 15:14:31', '西藏珠峰大本营5日游 ', '探险考察', 'http://localhost:8080/travels/upload/1708861571858.jpeg,http://localhost:8080/travels/upload/1708861740206.jpeg,http://localhost:8080/travels/upload/1708861830772.jpeg', '西藏珠峰大本营', '上海', '西藏拉萨', '飞机', '2024-05-13 15:14:31', '羊湖门票、卡若拉冰川门票、珠峰门票、珠峰观光车、扎什伦布寺门票。', '<p><img src=\"https://sales.mafengwo.net/img/73/44/2a88ceb71f011b210a14897c13c92a2f.jpeg?imageView2%2F2%2Fw%2F1000%2Fq%2F90\"></p><p><img src=\"https://sales.mafengwo.net/img/6c/a9/07f21351314c49334e143f8d9562d217.jpeg?imageView2%2F2%2Fw%2F1000%2Fq%2F90\"></p>', '2024-02-25 13:15:25', 16, 2999);
INSERT INTO `lvyouxianlu` VALUES (33, '2024-05-13 15:14:31', '张家界凤凰古城5日游（森林公园+天门山+玻璃桥', '观光旅游', 'http://localhost:8080/travels/upload/1708862205541.jpeg,http://localhost:8080/travels/upload/1708862211710.jpeg,http://localhost:8080/travels/upload/1708862230088.jpg', '张家界凤凰古城5日游', '北京', '湖南张家界', '大巴', '2024-05-13 15:14:31', '行程中所列景点首道大门票\n\n张家界武陵源国家森林公园大门票\n\n张家界大峡谷玻璃桥大门票\n\n张家界天门山国家森林公园大门票\n\n芙蓉镇景区门票\n\n凤凰古城景区\n\n赠送65元/人百龙天梯\n\n赠送88元/人七十二奇楼夜场门票\n\n赠送芙蓉镇环保车28元/人\n\n赠送湘见沱江泛舟68元/人\n\n赠送项目如不参加、未营业，无退费', '<p><img src=\"http://localhost:8080/travels/upload/1708862307980.jpeg\"></p><p><img src=\"http://localhost:8080/travels/upload/1708862191696.jpeg\"></p><p><br></p>', '2024-02-25 13:20:05', 10, 999);
INSERT INTO `lvyouxianlu` VALUES (34, '2024-05-13 15:14:31', '【川西小环线4日】', '远程旅游', 'http://localhost:8080/travels/upload/1708862511964.jpeg,http://localhost:8080/travels/upload/1708862519339.jpeg,http://localhost:8080/travels/upload/1708862525810.jpeg', '川西小环线4日', '郑州', '四川', '高铁', '2024-05-13 15:14:31', '根据参团人数调派车型，保证一人一正座\n\n接送：出行当天早上成都三环以内上门接早（特殊节假日集合地点以出发前司机师傅通知实际地点为准）\n\n2-8人纯玩min小团：3-4人安排5座SUV，5-8人安排7-9座商务车，根据当天报名人数随机安排车型（如需升级空位团可补100/人差价升级）。\n\n包含车辆燃油费、停车费、高速费、车辆使用费、进城费、拥堵费；\n\n【关于司机餐食和住宿】所有套餐均已包含司机餐食+住宿补贴，无需您额外AA；', '<p><img src=\"http://localhost:8080/travels/upload/1708862545676.jpeg\"><img src=\"http://localhost:8080/travels/upload/1708862551538.jpeg\"></p>', '2024-02-25 12:46:43', 9, 1399);
INSERT INTO `lvyouxianlu` VALUES (35, '2024-05-13 15:14:31', '云南丽江大理香格里拉泸沽湖9日游（豪华高档酒店任选+吉普车旅拍+网红S弯+圣托里尼+玉龙雪山+独克宗+猪槽船游湖登岛）', '观光旅游', 'http://localhost:8080/travels/upload/1708862764610.jpeg,http://localhost:8080/travels/upload/1708862771230.jpeg,http://localhost:8080/travels/upload/1708862779131.jpeg', '云南丽江大理', '信阳', '丽江', '飞机', '2024-05-13 15:14:31', '行程中所列餐食，包含8餐：4早餐，3午餐，1晚餐\n\n早餐酒店提供，正餐10菜一汤，十人一桌；餐标20（如果客人自愿放弃用餐，餐费一律不予退还）', '<p><img src=\"http://localhost:8080/travels/upload/1708862800459.jpeg\"></p><p><img src=\"http://localhost:8080/travels/upload/1708862811317.jpeg\"></p>', '2024-02-25 12:07:27', 17, 2699);
INSERT INTO `lvyouxianlu` VALUES (1614757564118, '2024-05-13 15:46:03', '云南6天5晚', '观光旅游', 'http://localhost:8080/travels/upload/1614757486132.jpg', '丽江古城，玉龙雪山，苍山洱海', '广州', '云南', '飞机', '2024-03-04 05:00:00', '机票，住宿费，餐费等', '<p>第1天 昆明长水机场接机--入住酒店--云南夜色</p><p>第2天 游石林-感受“世界自然遗产风光”+石林彝族风味餐</p><p>第3天 大理洱海环游，敞篷吉普车豪华私人游艇+渔鹰表演+罗荃半岛-苍山-蝴蝶泉</p><p>第4天 大理古城 洋人街 拉市海 下午在木府俯瞰丽江古城，欣赏歌舞丽水金沙 晚上纳西族喜宴</p><p>第5天 幽静古朴的束河古镇，海拔4680米的玉龙雪山+冰川大索道+蓝月谷+白水河</p><p>第6天 亚洲最大的鲜花市场，24小时根据航班送到机场或车站</p><p><br></p>', '2024-02-25 12:08:18', 3, 2500);
INSERT INTO `lvyouxianlu` VALUES (1708863081954, '2024-02-25 20:11:21', '贵州全景4日游·宿2晚景区·梵净山+黄果树瀑布+西江千户苗寨+荔波小七孔+镇远古镇精品纯玩·贵阳出发', '文化旅游', 'http://localhost:8080/travels/upload/1708862998342.jpeg,http://localhost:8080/travels/upload/1708863043600.jpeg', '贵州全景4日游·宿2晚', '商丘', '贵州', '轮渡', '2024-02-25 12:10:12', '景点门票	\n行程中所列景点首道大门票，不含景区小景点门票', '<p><img src=\"http://localhost:8080/travels/upload/1708863035953.jpeg\"></p>', '2024-02-25 12:11:59', 3, 2399);
INSERT INTO `lvyouxianlu` VALUES (1708863348942, '2024-02-25 20:15:48', '达蓝梦岛双岛一日游 海上浮台（海底漫步+浮潜+香蕉船+深潜+甜甜圈+恶魔眼泪+梦幻海滩+精灵沙滩+天神浴池+树屋）', '度假旅游', 'http://localhost:8080/travels/upload/1708863265264.jpeg,http://localhost:8080/travels/upload/1708863272166.jpeg', '达蓝梦岛双岛', '上海', '印度尼西亚', '飞机', '2024-02-25 12:15:00', '行程中所列餐食，包含1餐：0早餐，1午餐，0晚餐\n\n视套餐不同，餐食不同', '<p><img src=\"http://localhost:8080/travels/upload/1708863342755.jpeg\"></p>', NULL, 0, 7899);
INSERT INTO `lvyouxianlu` VALUES (1708863464066, '2024-02-25 20:17:43', '巴厘岛罗威纳海滩一日游【专车出行-含早餐-追海豚军团看日出-鹿岛浮潜/深潜|火山温泉|越野ATV|双子湖百度库】', '度假旅游', 'http://localhost:8080/travels/upload/1708863389720.jpeg,http://localhost:8080/travels/upload/1708863442682.jpeg', '巴厘岛罗威纳海滩一日游', '南京', '巴厘岛', '火车', '2024-02-29 12:17:03', '景点门票	\n行程中所列景点首道大门票\n\n餐食	\n行程中所列餐食，本行程不含餐，全程餐费自理\n\n司导服务	\n当地英文司机兼向导', '<p><img src=\"http://localhost:8080/travels/upload/1708863436583.jpeg\"></p>', NULL, 0, 6499);
INSERT INTO `lvyouxianlu` VALUES (1708863745615, '2024-02-25 20:22:24', '泰国普吉斯米兰岛一日游（全新网红码头+中文导游+一次性咬嘴+全岛接送+2次浮潜2次登岛）', '文化旅游', 'http://localhost:8080/travels/upload/1708863571709.jpeg,http://localhost:8080/travels/upload/1708863578538.jpeg', '泰国普吉斯米兰岛一日游', '成都', '泰国', '轮渡', '2024-02-25 12:22:05', '景点门票	\n行程中所列景点首道大门票\n\n当地交通	\n接送：酒店拼车接送\n\n餐食	\n行程中所列餐食，包含3餐：1早餐，1午餐，1晚餐\n\n司导服务	\n当地中文导游', '<p><img src=\"http://localhost:8080/travels/upload/1708863591129.jpeg\"></p><p><img src=\"http://localhost:8080/travels/upload/1708863683002.webp\"></p>', '2024-02-25 12:26:19', 1, 9800);
INSERT INTO `lvyouxianlu` VALUES (1708864251031, '2024-02-25 20:30:50', '北海道洞爷湖+登别地狱谷+支笏湖+昭和新山一日游', '短程旅游', 'http://localhost:8080/travels/upload/1708864065881.jpeg', '北海道', '南京', '北海道', '高铁', '2024-02-25 12:27:59', '景点门票	\n行程中所列景点首道大门票，登别地狱谷\n\n当地交通	\n根据参团人数调派车型，保证一人一正座\n\n餐食	\n行程中所列餐食，本行程不含餐，全程餐费自理\n\n司导服务	\n当地中文司机兼向导\n\n中文司导，只提供车内简单讲解，不提供景点下车讲解', '<p><img src=\"http://localhost:8080/travels/upload/1708864117817.jpg\"><img src=\"http://localhost:8080/travels/upload/1708864221738.jpg\"></p>', '2024-02-25 12:30:58', 1, 9999);

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news`  (
                         `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                         `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                         `title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '标题',
                         `introduction` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '简介',
                         `picture` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '图片',
                         `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '内容',
                         PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614757671445 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '旅游资讯' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES (101, '2024-05-13 15:14:31', '少林寺+龙门石窟一日游', '少林寺，是中国佛教禅宗祖庭和中国功夫的发源地之一国家5A级旅游景区\n武术表演不一定能看到，受交通，大家集合是否准时等情况影响，不一定能赶上固定场次的表演。行程时间也比较紧凑，如赶不上就直接逛景点了', 'http://localhost:8080/travels/upload/news_picture1.jpg', '<p><img src=\"http://localhost:8080/travels/upload/1708865428111.jpeg\"></p>');
INSERT INTO `news` VALUES (102, '2024-05-13 15:14:31', '系统维护升级通知', '系统维护期间可用', 'http://localhost:8080/travels/upload/news_picture2.jpg', '<p><img src=\"http://localhost:8080/travels/upload/1708865480656.jpg\"></p>');
INSERT INTO `news` VALUES (103, '2024-05-13 15:14:31', '关于近期收到导游强制购物的处罚通知', '关于近期收到导游强制购物的处罚通知', 'http://localhost:8080/travels/upload/news_picture3.jpg', '<p>经调查，田某某一行5人与云南国游国际旅行社有限公司昆明分公司签订旅游合同。该公司委托云南金树叶国际旅行社有限公司负责接待：导游张某提供跟团服务。根据行程安排，2月13日上午导游张某和团队到束河古镇一珠宝店，未发生强制购物。其间，导游张某按照旅行社要求，未征得游客书面同意，委托其他旅行社履行包价旅游合同，提出为田某某一行5人换车，双方发生分歧。经调解，旅行社单独安排车辆继续保障田某某一行5人在丽行程。</p><p>经查实，云南金树叶国际旅行社有限公司违反了《中华人民共和国旅游法》第六十九条之规定，丽江市文化和旅游局拟对云南金树叶国际旅行社有限公司作出吊销旅行社业务经营许可证的行政处罚；拟对直接负责的主管人员黄某作出罚款二万元的行政处罚，拟对导游张某作出罚款二万元、暂扣导游证三个月的行政处罚。</p>');


-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
                           `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                           `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                           `orderid` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '订单编号',
                           `tablename` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT 'zuixinxianlu' COMMENT '商品表名',
                           `userid` bigint NOT NULL COMMENT '用户id',
                           `goodid` bigint NOT NULL COMMENT '商品id',
                           `goodname` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '商品名称',
                           `picture` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '商品图片',
                           `buynumber` int NOT NULL COMMENT '购买数量',
                           `price` float NOT NULL DEFAULT 0 COMMENT '价格/积分',
                           `discountprice` float NULL DEFAULT 0 COMMENT '折扣价格',
                           `total` float NOT NULL DEFAULT 0 COMMENT '总价格/总积分',
                           `discounttotal` float NULL DEFAULT 0 COMMENT '折扣总价格',
                           `type` int NULL DEFAULT 1 COMMENT '支付类型',
                           `status` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '状态',
                           `address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '地址',
                           PRIMARY KEY (`id`) USING BTREE,
                           UNIQUE INDEX `orderid`(`orderid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614758027301 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '订单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (1614757238256, '2024-05-13 15:40:37', '20243315403614711707', 'lvyouxianlu', 1614756982123, 1614756810110, '云南大理丽江6天5晚', 'http://localhost:8080/travels/upload/1614756714294.jpg', 1, 2000, 2000, 3000, 2000, 1, '未支付', '广东省揭阳市榕城区中山街道北环城路16号中兴园');
INSERT INTO `orders` VALUES (1614757895454, '2024-05-13 15:51:34', '20243315513353374216', 'lvyouxianlu', 1614757696160, 1614757564118, '云南6天5晚', 'http://localhost:8080/travels/upload/1614757486132.jpg', 1, 2500, 2500, 2500, 2500, 1, '已完成', '广东省揭阳市榕城区中山街道Show艺数字油画中兴园');
INSERT INTO `orders` VALUES (1614758027300, '2024-05-13 15:53:46', '20213315534553649075', 'zuixinxianlu', 1614757696160, 1614757619035, '桂林4天3晚', 'http://localhost:8080/travels/upload/1614757585872.png', 1, 1200, 1200, 1200, 1200, 1, '已发货', '广东省揭阳市榕城区中山街道Show艺数字油画中兴园');

-- ----------------------------
-- Table structure for storeup
-- ----------------------------
DROP TABLE IF EXISTS `storeup`;
CREATE TABLE `storeup`  (
                            `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                            `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                            `userid` bigint NOT NULL COMMENT '用户id',
                            `refid` bigint NULL DEFAULT NULL COMMENT '收藏id',
                            `tablename` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '表名',
                            `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '收藏名称',
                            `picture` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '收藏图片',
                            PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614757858661 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '收藏表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of storeup
-- ----------------------------
INSERT INTO `storeup` VALUES (1614757107467, '2024-05-13 15:38:26', 1614756982123, 1614756810110, 'lvyouxianlu', '云南大理丽江6天5晚', 'http://localhost:8080/travels/upload/1614756714294.jpg');
INSERT INTO `storeup` VALUES (1614757140140, '2024-05-13 15:38:59', 1614756982123, 1614756888348, 'zuixinxianlu', '桂林阳朔4天3晚', 'http://localhost:8080/travels/upload/1614756840971.png');
INSERT INTO `storeup` VALUES (1614757812948, '2024-05-13 15:50:12', 1614757696160, 1614757564118, 'lvyouxianlu', '云南6天5晚', 'http://localhost:8080/travels/upload/1614757486132.jpg');
INSERT INTO `storeup` VALUES (1614757858660, '2024-05-13 15:50:57', 1614757696160, 1614757619035, 'zuixinxianlu', '桂林4天3晚', 'http://localhost:8080/travels/upload/1614757585872.png');
INSERT INTO `storeup` VALUES (1708861453857, '2024-02-25 19:44:13', 1708860588725, 31, 'lvyouxianlu', '上海迪士尼含门票+早享卡提前入园+快速游玩8大经典项目+专职导游管家式服务（精致团）', 'http://localhost:8080/travels/upload/lvyouxianlu_fengmiantu1.jpg');
INSERT INTO `storeup` VALUES (1708862597441, '2024-02-25 20:03:17', 1708860588725, 34, 'lvyouxianlu', '【川西小环线4日】Mini旅拍团·色达/四姑娘山/海螺沟/冷嘎措/月亮湖/雅拉雪山/牛背山/贡嘎雪山甲根坝2-8人单反/无人机星空亲子旅游', 'http://localhost:8080/travels/upload/1708862511964.jpeg');
INSERT INTO `storeup` VALUES (1708862598288, '2024-02-25 20:03:18', 1708860588725, 34, 'lvyouxianlu', '【川西小环线4日】Mini旅拍团·色达/四姑娘山/海螺沟/冷嘎措/月亮湖/雅拉雪山/牛背山/贡嘎雪山甲根坝2-8人单反/无人机星空亲子旅游', 'http://localhost:8080/travels/upload/1708862511964.jpeg');
INSERT INTO `storeup` VALUES (1708867274507, '2024-02-25 21:21:13', 1708860588725, 33, 'lvyouxianlu', '张家界凤凰古城5日游（森林公园+天门山+玻璃桥', 'http://localhost:8080/travels/upload/1708862205541.jpeg');

-- ----------------------------
-- Table structure for token
-- ----------------------------
DROP TABLE IF EXISTS `token`;
CREATE TABLE `token`  (
                          `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                          `userid` bigint NOT NULL COMMENT '用户id',
                          `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '用户名',
                          `tablename` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '表名',
                          `role` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '角色',
                          `token` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '密码',
                          `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
                          `expiratedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
                          PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = 'token表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of token
-- ----------------------------
INSERT INTO `token` VALUES (1, 1, 'abo', 'users', '管理员', '3e4v5f0inhovmyo3o89nol44ua9x4npm', '2024-05-13 15:19:57', '2024-02-25 13:34:05');
INSERT INTO `token` VALUES (2, 1614756982123, '1', 'yonghu', '用户', 'x1jatumvhfm9ra95gbc6d5538tt8niyt', '2024-05-13 15:36:27', '2024-05-13 08:36:28');
INSERT INTO `token` VALUES (3, 1614757696160, '2', 'yonghu', '用户', 'l4cfc4soq7d1xvs5rd8emc3yt8acwilq', '2024-05-13 15:48:21', '2024-05-13 08:52:51');


-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
                          `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                          `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '用户名',
                          `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '密码',
                          `role` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT '管理员' COMMENT '角色',
                          `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
                          PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '用户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'admin', 'admin', '管理员', '2024-05-13 15:14:31');

-- ----------------------------
-- Table structure for xianlufenlei
-- ----------------------------
DROP TABLE IF EXISTS `xianlufenlei`;
CREATE TABLE `xianlufenlei`  (
                                 `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                                 `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                                 `xianlufenlei` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '线路分类',
                                 PRIMARY KEY (`id`) USING BTREE,
                                 UNIQUE INDEX `xianlufenlei`(`xianlufenlei` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614757461166 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '线路分类' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of xianlufenlei
-- ----------------------------
INSERT INTO `xianlufenlei` VALUES (21, '2024-05-13 15:14:31', '观光旅游');
INSERT INTO `xianlufenlei` VALUES (22, '2024-05-13 15:14:31', '度假旅游');
INSERT INTO `xianlufenlei` VALUES (23, '2024-05-13 15:14:31', '探险考察');
INSERT INTO `xianlufenlei` VALUES (24, '2024-05-13 15:14:31', '文化旅游');
INSERT INTO `xianlufenlei` VALUES (25, '2024-05-13 15:14:31', '短程旅游');
INSERT INTO `xianlufenlei` VALUES (1614757461165, '2024-05-13 15:44:20', '远程旅游');

-- ----------------------------
-- Table structure for yonghu
-- ----------------------------
DROP TABLE IF EXISTS `yonghu`;
CREATE TABLE `yonghu`  (
                           `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                           `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                           `yonghuming` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '用户名',
                           `mima` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '密码',
                           `xingming` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '姓名',
                           `touxiang` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '头像',
                           `xingbie` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '性别',
                           `lianxidianhua` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '联系电话',
                           `money` float NULL DEFAULT 0 COMMENT '余额',
                           PRIMARY KEY (`id`) USING BTREE,
                           UNIQUE INDEX `yonghuming`(`yonghuming` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1708860588726 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '用户' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yonghu
-- ----------------------------

INSERT INTO `yonghu` VALUES (12, '2024-05-13 15:14:31', '用户2', '123456', '姓名2', 'http://localhost:8080/travels/upload/yonghu_touxiang2.jpg', '男', '13823888882', 100);
INSERT INTO `yonghu` VALUES (13, '2024-05-13 15:14:31', '用户3', '123456', '姓名3', 'http://localhost:8080/travels/upload/yonghu_touxiang3.jpg', '男', '13823888883', 100);
INSERT INTO `yonghu` VALUES (14, '2024-05-13 15:14:31', '用户4', '123456', '姓名4', 'http://localhost:8080/travels/upload/yonghu_touxiang4.jpg', '男', '13823888884', 100);
INSERT INTO `yonghu` VALUES (15, '2024-05-13 15:14:31', '用户5', '123456', '姓名5', 'http://localhost:8080/travels/upload/yonghu_touxiang5.jpg', '男', '13823888885', 100);
INSERT INTO `yonghu` VALUES (16, '2024-05-13 15:14:31', '用户6', '123456', '姓名6', 'http://localhost:8080/travels/upload/yonghu_touxiang6.jpg', '男', '13823888886', 100);
INSERT INTO `yonghu` VALUES (1614757696160, '2024-05-13 15:48:16', '2', '2', '陈一', 'http://localhost:8080/travels/upload/1614757715279.jpeg', '女', '12312345678', 1700);


-- ----------------------------
-- Table structure for zuixinxianlu
-- ----------------------------
DROP TABLE IF EXISTS `zuixinxianlu`;
CREATE TABLE `zuixinxianlu`  (
                                 `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
                                 `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                                 `xianlumingcheng` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '线路名称',
                                 `xianlufenlei` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '线路分类',
                                 `fengmiantu` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '封面图',
                                 `jingdianmingcheng` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '景点名称',
                                 `chufadi` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '出发地',
                                 `mudedi` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '目的地',
                                 `jiaotongfangshi` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '交通方式',
                                 `chuxingshijian` datetime NULL DEFAULT NULL COMMENT '出行时间',
                                 `feiyongbaohan` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '费用包含',
                                 `xingchengluxian` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '行程路线',
                                 `price` float NOT NULL COMMENT '价格',
                                 PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1614757619036 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '最新线路' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of zuixinxianlu
-- ----------------------------
INSERT INTO `zuixinxianlu` VALUES (41, '2024-05-13 15:14:31', '杭州西湖景区', '探险考察', 'http://localhost:8080/travels/upload/zuixinxianlu_fengmiantu1.jpg', '杭州西湖景区', '上海', '杭州', '大巴', '2024-05-13 15:14:31', '住宿,吃饭,门票', '<p><img src=\"http://localhost:8080/travels/upload/1614756033607.png\"></p><p><img src=\"http://localhost:8080/travels/upload/1708864520918.jpg\"></p>', 99.9);
INSERT INTO `zuixinxianlu` VALUES (42, '2024-05-13 15:14:31', '大豫中原 洛阳龙门石窟半日游（文史精讲 2-3小时多套餐可选 深度解密华夏五千年）', '文化旅游', 'http://localhost:8080/travels/upload/1708864656935.jpeg', '洛阳龙门石窟', '湖南', '洛阳', '大巴', '2024-05-13 15:14:31', '景点门票	\n行程中所列景点首道大门票，龙门石窟门票90/人\n\n餐食	\n行程中所列餐食，本行程不含餐，全程餐费自理\n\n司导服务	\n当地中文导游\n\n文博讲师', '<p><img src=\"http://localhost:8080/travels/upload/1708864650012.jpeg\"></p><p><img src=\"http://localhost:8080/travels/upload/1708864636245.jpg\"></p>', 99.9);
INSERT INTO `zuixinxianlu` VALUES (43, '2024-05-13 15:14:31', '开封清明上河园景区+大宋东京梦华演出联票（史诗级演出+出票快+位置好+服务好+百分百好评率+专人送票服务）', '文化旅游', 'http://localhost:8080/travels/upload/1708864741568.jpeg', '清明上河园景区', '新疆', '开封', '飞机', '2024-05-13 15:14:31', '1.清明上河园(门票)+《大宋·东京梦华》(A区票) 成人票 联票\n\n2.清明上河园(门票)+《大宋·东京梦华》(贵宾区票) 成人票 联票\n\n3.清明上河园(门票)+《大宋·东京梦华》(御座区) 成人票 联票', '<p><img src=\"http://localhost:8080/travels/upload/1708864784493.png\"></p><p><img src=\"http://localhost:8080/travels/upload/1708864806038.png\"><img src=\"http://localhost:8080/travels/upload/1708864857410.jpg\"></p>', 99.9);
INSERT INTO `zuixinxianlu` VALUES (46, '2024-05-13 15:14:31', '山西大槐树', '探险考察', 'http://localhost:8080/travels/upload/zuixinxianlu_fengmiantu6.jpg', '山西大槐树', '安徽湖北', '山西大槐树', '大巴', '2024-05-13 15:14:31', '费用包含6', '<p><img src=\"http://localhost:8080/travels/upload/1708864995509.webp\"></p>', 99.9);
INSERT INTO `zuixinxianlu` VALUES (1614757619035, '2024-05-13 15:46:58', '桂林4天3晚', '文化旅游', 'http://localhost:8080/travels/upload/1614757585872.png', '漓江', '梅州', '桂林', '高铁', '2024-05-13 07:46:40', '住宿费来回车费等', '<p><img src=\"http://localhost:8080/travels/upload/1614757617098.png\"></p>', 1200);

SET FOREIGN_KEY_CHECKS = 1;
